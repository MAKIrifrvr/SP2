#!/bin/sh

argument_size=$#

if [ "$argument_size" -lt 3 ]
then
echo "Too few arguments"

elif [ "$argument_size" -gt 3 ]
then
echo "Too many arguments"

elif [ "$argument_size" -eq 3 ]
then	
	DAY=$1
	MONTH=$2
	YEAR=$3
	
	isValid=0
	isLeapYear=0
	 
	if [ $((YEAR%4)) -eq 0 ]
	then
		
		isLeapYear=$((isLeapYear+1))
	fi
	if [ "$MONTH" -lt 13 ]	
	then
		if [ "$MONTH" -eq 1 ] || [ "$MONTH" -eq 3 ] || [ "$MONTH" -eq 5 ] || [ "$MONTH" -eq 7 ] || [ "$MONTH" -eq 8 ] || [ "$MONTH" -eq 10 ] || [ "$MONTH" -eq 12 ]
		then
			if [ "$DAY" -le 31 ]
			then
				isValid=$((isValid+1))
			fi
		elif [ "$MONTH" -eq 4 ] || [ "$MONTH" -eq 6 ] || [ "$MONTH" -eq 9 ] || [ "$MONTH" -eq 11 ]
		then
			if [ "$DAY" -le 30 ]
			then
				isValid=$((isValid+1))
			fi
		else
			if [ "$isLeapYear" -eq 1 ]
			then
				if [ "$DAY" -le 29 ]
				then
					isValid=$((isValid+1))
				fi
			fi
			if [ "$isLeapYear" -eq 0 ]
			then
				if [ "$DAY" -le 28 ]
				then
					isValid=$((isValid+1))
				fi
			fi
		fi
	fi

	if [ "$isValid" -eq 1 ]
	then
		DATE="$YEAR$MONTH$DAY"
		DAY="date -d $DATE '+%A'"
		eval $DAY
	else
		echo "invalid"
	fi



	
fi
