﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuickSort
{
    class Program
    {
        static void Main(string[] args)
        {
            QuickSortClass qSort = new QuickSortClass();
            qSort.askInput();
            qSort.quicksort(0, 9);
            qSort.printSortedArray();
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}