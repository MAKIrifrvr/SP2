﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuickSort
{
    class QuickSortClass
    {
        public int[] inputs = new int[10];

        public void quicksort(int low, int high)
        {
            int pivotLocation = 0;

            if (low < high)
            {
                pivotLocation = partition(low, high);
                quicksort(low, pivotLocation - 1);
                quicksort(pivotLocation + 1, high);
            }
        }

        private int partition(int low, int high)
        {
            int pivot = inputs[high];
            int i = low - 1;

            for (int j = low; j < high; j++)
            {
                if (inputs[j] <= pivot)
                {
                    i++;
                    swap(i, j);
                }
            }
            swap(i + 1, high);
            return i + 1;
        }

        private void swap(int x, int y)
        {
            int temp = inputs[x];
            inputs[x] = inputs[y];
            inputs[y] = temp;
        }

        public void askInput()
        {
            int inputNum = 1;
            int tempInput = 0;

            Console.WriteLine("\n\nQuick Sort Algorithm");
            while (inputNum <= 10)
            {
                Console.Write("input " + inputNum + ": ");
                if (int.TryParse(Console.ReadLine(), out tempInput))
                {
                    inputs[inputNum - 1] = tempInput;
                    inputNum++;
                }
                else
                {
                    Console.WriteLine("  Error: Invalid user input");
                }
            }
        }

        public void printSortedArray()
        {
            Console.Write("\n  Sorted Values: ");
            for (int a = 0; a < inputs.Length; a++)
            {
                Console.Write(inputs[a] + " ");
            }
        }
    }
}