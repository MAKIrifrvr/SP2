﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            HashTableClass hashtable = new HashTableClass();
            hashtable.commandInterface();
            Console.ReadLine();
        }
    }
}