﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HashTable
{
    class HashKey
    {
        public HashKey(int item_i, HashKey next_p)
        {
            this.item_i = item_i;
            this.next_p = next_p;
        }

        public int item_i { get; set; }
        public HashKey next_p { get; set; }
    }
}