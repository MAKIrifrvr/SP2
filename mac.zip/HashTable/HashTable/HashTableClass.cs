﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HashTable
{
    class HashTableClass
    {
        //initialize a hashtable with 10 keys with null values.
        static HashKey[] table =
            new HashKey[]{
                new HashKey(0,null),
                new HashKey(1,null),
                new HashKey(2,null),
                new HashKey(3,null),
                new HashKey(4,null),
                new HashKey(5,null),
                new HashKey(6,null),
                new HashKey(7,null),
                new HashKey(8,null),
                new HashKey(9,null)
            };

        //prints the hashtable
        public void printHashTable()
        {
            Console.WriteLine("{0,5}  {1,-10}", "\nHashValue", "  Keys");
            string tempKey;

            for (int a = 0; a < 10; a++)
            {
                tempKey = "";
                if (table[a].next_p == null)
                {
                    tempKey = " -";
                }
                else
                {
                    HashKey temp = table[a].next_p;
                    while (temp != null)
                    {
                        tempKey = string.Concat(tempKey + " " + temp.item_i);
                        temp = temp.next_p;
                    }
                }
                Console.WriteLine("{0,5}       {1,-50}", table[a].item_i, tempKey);
            }
            Console.WriteLine();
        }

        //adds new element to the hashtable
        public int add(int item_i)
        {
            HashKey tempNode = new HashKey(item_i, null);
            int hashKey = item_i % 10;                          //computes the key where the new element will be inserted

            if (table[hashKey].next_p == null)
            {
                table[hashKey].next_p = tempNode;               //set the new element as the first value of the key when the key has null valu
            }
            else
            {
                tempNode.next_p = table[hashKey].next_p;        // set the new element as the first element of the key and points it to the
                table[hashKey].next_p = tempNode;               // previous first element.  (Insert head)
            }
            return 0;
        }

        //deletes the desired element from the hashtable
        public int remove(int item_i)
        {
            int hashKey = item_i % 10;
            HashKey temp = table[hashKey].next_p;
            if (temp == null)
            {   //if the key of the desired element to be deleted has null values.
                return -1;      
            }

            else if (temp.item_i == item_i)
            {   //if the first value of the key is the desired element to be deleted
                table[hashKey].next_p = temp.next_p;
                return 0;
            }
            else
            {   //traverse the values in the key and check if the desired element to be deleted is in the hashtable
                while (temp.next_p != null && temp.next_p.item_i != item_i)
                {
                    temp = temp.next_p;
                }
                if (temp.next_p.item_i == item_i)
                {
                    temp.next_p = temp.next_p.next_p;
                    return 0;
                }
                else
                {
                    return -1;
                }
            }

        }

        public void commandInterface()
        {
            string[] tokens;
            do
            {
                Console.Write("prompt> ");
                tokens = Console.ReadLine().Split();
                int temp = 0;
                switch (tokens[0])
                {
                    case "add":
                        if (tokens.Length != 2)
                        {
                            Console.WriteLine("  Invalid parameter");
                        }
                        else
                        {
                            if (int.TryParse(tokens[1], out temp) && temp >= 0)
                            {
                                add(temp);
                                Console.WriteLine("  Successfully added key value " + temp);
                            }
                            else
                            {
                                Console.WriteLine("  Invalid parameter");
                            }
                        }
                        break;
                    case "rm":
                        if (tokens.Length != 2)
                        {
                            Console.WriteLine("  Invalid parameter");
                        }
                        else
                        {
                            if (int.TryParse(tokens[1], out temp) && temp >= 0)
                            {
                                if (remove(temp) == 0)
                                {
                                    Console.WriteLine("  Successfully removed key value " + temp);
                                }
                                else
                                {
                                    Console.WriteLine("  Error: key with value " + temp + " is not in the hash table");
                                }
                            }
                            else
                            {
                                Console.WriteLine("  Invalid parameter");
                            }
                        }
                        break;
                    case "print":
                        printHashTable();
                        break;
                    default:
                        Console.WriteLine("  Invalid command");
                        break;
                }
            } while (tokens[0] != "bye");

        }
    }
}