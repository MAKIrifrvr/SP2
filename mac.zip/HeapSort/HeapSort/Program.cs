﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeapSort
{
    class Program
    {
        static void Main(string[] args)
        {
            HeapSortClass hSort = new HeapSortClass();
            hSort.askInput();
            hSort.heapsort();
            hSort.printSortedArray();
            Console.ReadKey();
        }
    }
}