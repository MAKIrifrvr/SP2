﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeapSort
{
    class HeapSortClass
    {
        public int[] inputs = new int[10];
        public int heapSize = 0;
        
        private void buildheap()
        {
            heapSize = inputs.Length - 1;
            for (int i = heapSize / 2; i >= 0; i--)
            {
                Heapify(i);
            }
        }

        private void Heapify(int index)
        {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int largest = index;
            if (left <= heapSize && inputs[left] > inputs[index])
            {
                largest = left;
            }

            if (right <= heapSize && inputs[right] > inputs[largest])
            {
                largest = right;
            }

            if (largest != index)
            {
                Swap(index, largest);
                Heapify(largest);
            }
        }

        private void Swap(int x, int y)
        {
            int temp = inputs[x];
            inputs[x] = inputs[y];
            inputs[y] = temp;
        }

        public void heapsort()
        {
            buildheap();
            for (int i = inputs.Length - 1; i >= 0; i--)
            {
                Swap(0, i);
                heapSize--;
                Heapify(0);
            }
        }

        public void askInput()
        {
            int inputNum = 1;
            int tempInput = 0;

            Console.WriteLine("\n\nHeap Sort Algorithm");
            while (inputNum <= 10)
            {
                Console.Write("input " + inputNum + ": ");
                if (int.TryParse(Console.ReadLine(), out tempInput))
                {
                    inputs[inputNum - 1] = tempInput;
                    inputNum++;
                }
                else
                {
                    Console.WriteLine("  Error: Invalid user input");
                }
            }
        }

        public void printSortedArray()
        {
            Console.Write("\n  Sorted Values: ");
            for (int a = 0; a < inputs.Length; a++)
            {
                Console.Write(inputs[a] + " ");
            }
        }
    }
}