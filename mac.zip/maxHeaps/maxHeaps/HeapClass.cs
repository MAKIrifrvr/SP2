﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace maxHeaps
{
    class HeapClass
    {
        private Node root = null;
        private int HeapSize = 0;

        public void insert(int item_i)
        {
            if (root == null)
            {   //insert if tree is empty
                root = new Node();
                root.value_i = item_i;
                root.left_p = null;
                root.right_p = null;
                root.parent_p = null;
                HeapSize++;

            }
            else
            {   //insert if tree is not empty
                Node toAdd = new Node();
                toAdd.value_i = item_i;
                toAdd.left_p = null;
                toAdd.right_p = null;
                HeapSize++;
                searchInsertPosition(root, toAdd);      //search for the right position to insert the new node
                insertHeapify(toAdd);                   //check and re-arrange the tree after insert
            }

        }


        /* Find the position to insert based on the size of the tree.
         * Convert the next position of new node (Heapsize) to binary
         * and remove the leftmost digit. Next, the resulting binary
         * will be the movement to traverse the tree from the root 
         * to the new position. '0' means traverse to left child and
         * '1' means traverse to right child.*/

        public void searchInsertPosition(Node tempNode, Node toAdd)
        {  
            string result = Convert.ToString(HeapSize, 2);
            for (int count = 1; count < result.Length; count++)
            {
                switch (result[count])
                {
                    case '0':
                        if (tempNode.left_p != null)
                        {
                            tempNode = tempNode.left_p;
                        }
                        else
                        {
                            tempNode.left_p = toAdd;
                            toAdd.parent_p = tempNode;
                        }
                        break;

                    case '1':
                        if (tempNode.right_p != null)
                        {
                            tempNode = tempNode.right_p;
                        }
                        else
                        {
                            tempNode.right_p = toAdd;
                            toAdd.parent_p = tempNode;
                        }
                        break;
                }
            }
        }

        //check if the tree maintains the characteristics of a max-heap after inserting
        public void insertHeapify(Node temp)
        {
            if (temp.parent_p != null && temp.value_i > temp.parent_p.value_i)
            {
                int tempValue = 0;
                if (temp.parent_p == root)
                {
                    tempValue = root.value_i;
                    root.value_i = temp.value_i;
                    temp.value_i = tempValue;
                }
                else
                {
                    tempValue = temp.parent_p.value_i;
                    temp.parent_p.value_i = temp.value_i;
                    temp.value_i = tempValue;
                }
                insertHeapify(temp.parent_p);
            }
        }

        public Boolean checkIfEmpty()
        {
            if (root == null)
            {
                Console.WriteLine("  List is empty");
                return true;
            }
            else
            {
                return false;
            }
        }


        public void printLevelOrder(Node root)
        {
            int h = height(root);
            int i;
            for (i = 1; i <= h; i++)
            {
                printGivenLevel(root, i);
            }
        }

        //prints nodes in each level
        public void printGivenLevel(Node root, int level)
        {
            if (root == null)
            {
                return;
            }
            if (level == 1)
            {
                Console.Write(root.value_i + " ");
            }
            else if (level > 1)
            {
                printGivenLevel(root.left_p, level - 1);
                printGivenLevel(root.right_p, level - 1);
            }
        }

        //computes for the height of the tree
        public int height(Node node)
        {
            if (node == null)
            {
                return 0;
            }
            else
            {
                int lheight = height(node.left_p);
                int rheight = height(node.right_p);
                if (lheight > rheight)
                {
                    return (lheight + 1);
                }
                else
                {
                    return (rheight + 1);
                }
            }
        }



        public int remove(Node tempNode, int item_i)
        {
            if (item_i == tempNode.value_i)
            {
                if (tempNode == root && HeapSize == 1)
                {
                    HeapSize--;
                    root = null;
                    return 0;
                }
                else
                {
                    Node tempNode1 = root;
                    string result = Convert.ToString(HeapSize, 2);
                    for (int count = 1; count < result.Length; count++)
                    {
                        switch (result[count])
                        {
                            case '0':
                                tempNode1 = tempNode1.left_p;
                                break;

                            case '1':
                                tempNode1 = tempNode1.right_p;
                                break;
                        }
                    }
                    tempNode.value_i = tempNode1.value_i;
                    if (tempNode1.parent_p.left_p == tempNode1)
                    {
                        tempNode1.parent_p.left_p = null;
                    }
                    else
                    {
                        tempNode1.parent_p.right_p = null;
                    }
                    HeapSize--;
                    deleteHeapify(tempNode);
                    return 0;
                }

            }
            else if (tempNode.left_p != null)
            {
                return remove(tempNode.left_p, item_i);
            }
            else if (tempNode.right_p != null)
            {
                return remove(tempNode.right_p, item_i);
            }
            else
            {
                return -1;
            }
        }

        //check if the tree maintains the characteristics of a max-heap after deletion
        public void deleteHeapify(Node tempNode)
        {
            Node largestChild = new Node();
            int tempValue = 0;

            if (tempNode.left_p != null && tempNode.right_p != null)
            {
                if (tempNode.left_p.value_i >= tempNode.right_p.value_i)
                {
                    largestChild = tempNode.left_p;
                }
                else
                {
                    largestChild = tempNode.right_p;
                }
            }

            else if (tempNode.left_p != null)
            {
                largestChild = tempNode.left_p;
            }

            else if (tempNode.right_p != null)
            {
                largestChild = tempNode.right_p;
            }

            if (tempNode.value_i < largestChild.value_i)
            {
                tempValue = tempNode.value_i;
                tempNode.value_i = largestChild.value_i;
                largestChild.value_i = tempValue;
                deleteHeapify(largestChild);
            }
        }

        public void commandInterface()
        {
            string[] tokens;
            do
            {
                Console.Write("prompt> ");
                tokens = Console.ReadLine().Split();
                int temp = 0;
                switch (tokens[0])
                {
                    case "ins":
                        if (tokens.Length != 2)
                        {
                            Console.WriteLine("  Invalid parameter");
                        }
                        else
                        {
                            if (int.TryParse(tokens[1], out temp) && temp >= 0)
                            {
                                insert(temp);
                                Console.WriteLine("  Successfully inserted node with value " + temp);
                            }
                            else
                            {
                                Console.WriteLine("  Invalid parameter");
                            }
                        }
                        break;
                    case "rm":
                        if (tokens.Length != 2)
                        {
                            Console.WriteLine("  Invalid parameter");
                        }
                        else
                        {
                            if (int.TryParse(tokens[1], out temp) && temp >= 0)
                            {
                                if (checkIfEmpty() == false)
                                {
                                    if (remove(root, temp) == 0)
                                    {
                                        Console.WriteLine("  Successfully removed node with value " + temp);
                                    }
                                    else
                                    {
                                        Console.WriteLine("  Error: node with value " + temp + " is not in the heap");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("  Invalid parameter");
                            }
                        }
                        break;
                    case "levelo":
                        if (checkIfEmpty() == false)
                        {
                            Console.Write("  ");
                            printLevelOrder(root);
                            Console.WriteLine();
                        }
                        break;
                    case "bye":
                        Console.WriteLine("  Bye!!");
                        break;
                    default:
                        Console.WriteLine("  Invalid command");
                        break;
                }
            } while (tokens[0] != "bye");
        }
    }
}