﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            QueueClass myList = new QueueClass();
            myList.printQueueMenu(); //print the menu and ask for user input
            Console.ReadKey();
        }
    }
}
