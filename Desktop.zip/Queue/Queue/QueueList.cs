﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Queue
{
    class QueueClass
    {
        public int queueSize = 0;
        private Node frontNode = null;

        public int size()
        {
            return queueSize;
        }
        public void enqueue(int item_i)
        {
            queueSize++;
            if (frontNode == null)
            {
                frontNode = new Node();
                frontNode.value_i = item_i;
                frontNode.next_p = null;
            }
            else
            {
                Node toAdd = new Node();
                toAdd.value_i = item_i;
                toAdd.next_p = null;

                Node current = frontNode;
                while (current.next_p != null)
                {
                    current = current.next_p;
                }

                current.next_p = toAdd;
                current.next_p.next_p = null;
            }
        }

        public int dequeue()
        {
            if (frontNode == null)
            {
                return -1;
            }
            else
            {
                queueSize--;
                Node current = frontNode;
                frontNode = frontNode.next_p;
                return current.value_i;
            }
        }


        public void printInfo()
        {
            if (frontNode == null)
            {
                Console.WriteLine("\r\nNo Contents");
            }
            else
            {
                Console.Write("Contents:");
                printList();
            }
        }
        public void printList()
        {
            Node current = frontNode;
            while (current != null)
            {
                Console.Write(" " + current.value_i);
                current = current.next_p;
            }
        }
        public void printPressEnter()
        {
            Console.Write("\r\n\r\nPress enter to continue...\r\n\r\n");
            Console.ReadLine();
        }

        public int checkIfValidInput(string tempValue)
        {
            int stringToIntVal = 0;
            if (int.TryParse(tempValue, out stringToIntVal))
                return stringToIntVal;
            else return -1;
        }

        public int front()
        {
            return frontNode.value_i;
        }
        
        public void printQueueMenu()
        {
            string choice;
            string tempValue;
            do
            {
                Console.Clear();
                Console.WriteLine("\r\n+-- MENU --+");
                Console.WriteLine("[1] print info");
                Console.WriteLine("[2] enqueue");
                Console.WriteLine("[3] dequeue");
                Console.WriteLine("[4] view front");
                Console.WriteLine("[5] exit\r\n");
                Console.Write("Choice:");
                choice = Console.ReadLine();
                Console.Clear();
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("-= Queue Info =-\r\n");
                        Console.WriteLine("\r\nItems in the queue: " + size());
                        printInfo();
                        printPressEnter();
                        break;

                    case "2":
                        Console.WriteLine("-= Enqueue to Queue =-\r\n");
                        Console.Write("Enqueue Item: ");
                        tempValue = Console.ReadLine();
                        if (checkIfValidInput(tempValue) == -1)
                            Console.WriteLine("\r\n\r\n Invalid Input");
                        else
                        {
                            enqueue(checkIfValidInput(tempValue));
                            Console.Write("\r\nEnqueue Successful");
                        }
                        printPressEnter();
                        break;

                    case "3":
                        Console.WriteLine("-= Dequeue from Queue =-\r\n");
                        int ret = dequeue();
                        if (ret == -1)
                            Console.WriteLine("\r\nNo Contents");
                        else
                            Console.WriteLine("\r\nDequeue Successful\r\n");

                        printPressEnter();
                        break;

                    case "4":
                        Console.WriteLine("-= View Front =-\r\n");
                        if (frontNode == null)
                            Console.WriteLine("\r\nNo Contents");
                        else
                            Console.WriteLine("\r\nFront: " + front());

                        printPressEnter();
                        break;

                    case "5":
                        Console.WriteLine("\r\nBye!");
                        break;
                    default:
                        Console.WriteLine("\r\n Invalid Input! \r\n");
                        printPressEnter();
                        break;
                }
            } while (choice != "5");
        }
    }
}
