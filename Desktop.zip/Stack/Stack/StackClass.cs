﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stack
{
    class StackClass
    {
        public int stackSize = 0;
        private Node head = null;
        private Node topNode = null;
        public void push(int item_i)
        {
            topNode = head;
            stackSize++;
            if (head == null)
            {
                head = new Node();
                head.value_i = item_i;
                head.next_p = null;
                topNode = head;
            }
            else
            {

                Node toAdd = new Node();
                toAdd.value_i = item_i;
                toAdd.next_p = null;

                Node current = head;
                while (current.next_p != null)
                {
                    current = current.next_p;
                }

                current.next_p = toAdd;
                current.next_p.next_p = null;
                topNode = toAdd;
            }
        }

        public int pop()
        {
            int ret_val = 0;
            if (head == null)
            {
                return -1;
            }
            else
            {
                if (head == topNode)
                {
                    stackSize--;
                    ret_val = topNode.value_i;
                    topNode = null;
                    head = null;
                    return ret_val;
                }
                else
                {
                    Node current = head;
                    while(current.next_p != topNode)
                    {
                        current = current.next_p;
                    }
                    stackSize--;
                    ret_val = topNode.value_i;
                    current.next_p = null;
                    topNode = current;
                    return ret_val;
                }
                
            }
        }

        public int top()
        {
            return topNode.value_i;
        }

        public void printInfo()
        {
            if (head == null)
            {
                Console.WriteLine("\r\nNo Contents");
            }
            else
            {
                Console.Write("Contents:");
                printList();
            }
        }
        public void printList()
        {
            Node current = head;
            while (current != null)
            {
                Console.Write(" " + current.value_i);
                current = current.next_p;
            }
        }
        public void printPressEnter()
        {
            Console.Write("\r\n\r\nPress enter to continue...\r\n\r\n");
            Console.ReadLine();
        }

        public int checkIfValidInput(string tempValue)
        {
            int stringToIntVal = 0;
            if (int.TryParse(tempValue, out stringToIntVal))
                return stringToIntVal;
            else return -1;
        }

        public void printStackMenu()
        {
            string choice;
            string tempValue;
            do
            {
                Console.Clear();
                Console.WriteLine("\r\n+-- MENU --+");
                Console.WriteLine("[1] print info");
                Console.WriteLine("[2] push");
                Console.WriteLine("[3] pop");
                Console.WriteLine("[4] view top");
                Console.WriteLine("[5] exit\r\n");
                Console.Write("Choice:");
                choice = Console.ReadLine();
                Console.Clear();
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("-= Stack Info =-\r\n");
                        Console.WriteLine("\r\nItems in the stack: " + stackSize);
                        printInfo();
                        printPressEnter();
                        break;

                    case "2":
                        Console.WriteLine("-= Push to Stack =-\r\n");
                        Console.Write("Input Item: ");
                        tempValue = Console.ReadLine();
                        if (checkIfValidInput(tempValue) == -1)
                            Console.WriteLine("\r\n\r\n Invalid Input");
                        else
                        {
                            push(checkIfValidInput(tempValue));
                            Console.Write("\r\nInsert Successful");
                        }
                        printPressEnter();
                        break;

                    case "3":
                        Console.WriteLine("-= Pop to Stack =-\r\n");
                        int ret = pop();
                        if (ret == -1)
                            Console.WriteLine("\r\nNo Contents");
                        else
                            Console.WriteLine("\r\nPop Successful\r\n");

                        printPressEnter();
                        break;

                    case "4":
                        Console.WriteLine("-= View Top =-\r\n");
                        if (topNode == null)
                            Console.WriteLine("\r\nNo Contents");
                        else
                            Console.WriteLine("\r\nTop: " + top());

                        printPressEnter();
                        break;

                    case "5":
                        Console.WriteLine("\r\nBye");
                        break;
                    default:
                        Console.WriteLine("\r\n Invalid Input! \r\n");
                        printPressEnter();
                        break;
                }
            } while (choice != "5");
        }
    }
}
