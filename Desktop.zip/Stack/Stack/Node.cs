﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stack
{
    class Node
    {
        public Node next_p;
        public int value_i;
    }
}
