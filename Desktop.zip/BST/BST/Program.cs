﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    class Program
    {
        static void Main(string[] args)
        {
            BSTClass myList = new BSTClass();
            myList.commandInterface(); //print the menu and ask for user input
            Console.ReadKey();  //wait for keypress before exiting the program
        }
    }
}
