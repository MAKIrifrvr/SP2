﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    class Node
    {
        public Node left_p;
        public Node right_p;
        public Node parent_p;
        public int value_i;
    }
}
