﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    class BSTClass
    {
        private Node root = null;
        private int BSTSize = 0;

        public void insert(int item_i)
        {
            BSTSize++;
            if (root == null)
            {
                root = new Node();
                root.value_i = item_i;
                root.left_p = null;
                root.right_p = null;
                root.parent_p = null;
            }
            else
            {
                Node toAdd = new Node();
                toAdd.value_i = item_i;
                searchInsertPosition(root,toAdd);
            }
        }

        public void searchInsertPosition(Node tempNode, Node toAdd)
        {

            if (tempNode.value_i <= toAdd.value_i && tempNode.right_p != null)
            {
                searchInsertPosition(tempNode.right_p, toAdd);
            }
            else if (tempNode.value_i > toAdd.value_i && tempNode.left_p != null)
            {
                searchInsertPosition(tempNode.left_p, toAdd);
            }else if (tempNode.value_i <= toAdd.value_i && tempNode.right_p == null)
            {
                tempNode.right_p = toAdd;
            }
            else if (tempNode.value_i > toAdd.value_i && tempNode.left_p == null)
            {
                tempNode.left_p = toAdd;
            }
        }

        public void inorder(Node tempNode)
        {
            if (tempNode == null) Console.WriteLine("mac");
            else
            {
                if (tempNode.left_p != null) inorder(tempNode.left_p);
                Console.Write(tempNode.value_i + " ");
                if (tempNode.right_p != null) inorder(tempNode.right_p);
            }
        }
        public int minimum(Node temp)
        {
            if (temp == null) return -1;
            else
            {
                if (temp.left_p != null)
                {
                    return (minimum(temp.left_p));
                }
                else
                {
                    return temp.value_i;
                }
            }
        }

        public int maximum(Node temp)
        {
            if (temp == null) return -1;
            else
            {
                if (temp.right_p != null)
                {
                    return (maximum(temp.right_p));
                }
                else
                {
                    return temp.value_i;
                }
            }
        }

        public void commandInterface()
        {
            string[] tokens;
            do
            {
                Console.Write("prompt> ");
                tokens = Console.ReadLine().Split();
                if (tokens.Length > 2)
                {
                    Console.WriteLine("Error\n");
                }
                else
                {
                    int temp = 0;
                    switch (tokens[0])
                    {
                        case "find":
                            if (tokens.Length == 2 && int.TryParse(tokens[1], out temp))
                                Console.WriteLine("Correct\n");
                                
                            else
                                Console.WriteLine("Error Input\n");
                            break;
                        case "ins":
                            int x = 0;
                            if (int.TryParse(tokens[1], out x) && x >= 0)
                            {
                                insert(x);
                            } 
                           
                            break;
                        case "rm":

                            break;
                        case "min":
                            Console.WriteLine(minimum(root));                          
                            break;
                        case "max":
                            Console.WriteLine(maximum(root));
                            break;
                        case "succ":
                            inorder(root);
                            break;
                        case "pred":
                            inorder(root);
                            break;
                        case "preo":
                            inorder(root);
                            break;
                        case "posto":
                            inorder(root);
                            break;
                        case "ino":
                            inorder(root);
                            break;
                        case "levelo":
                            inorder(root);
                            break;
                        case "bye":
                            Console.WriteLine("Bye");
                            break;
                        default:
                            Console.WriteLine("Invalid");
                            break;
                    }
                }
            } while (tokens[0] != "bye");
            

        }

    }
}
